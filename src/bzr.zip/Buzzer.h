//
//  Breezer.h
//
//  Created by CATEDS on 2024-5-9.
//  Copyright © 2024 DT5EDU.
//  All rights reserved.
//

#ifndef _CATEDS_MS_Buzzer_
#define _CATEDS_MS_Buzzer_

#include "mbed.h"
#include <unordered_map>
#include <vector>

namespace DT5EDU {

enum class Tune {
    C3,C3s,D3,D3s,E3,F3,F3s,G3,G3s,A3,A3s,B3,
    C4,C4s,D4,D4s,E4,F4,F4s,G4,G4s,A4,A4s,B4,
    C5,C5s,D5,D5s,E5,F5,F5s,G5,G5s,A5,A5s,B5,
    Pause,Sustain
};

extern std::unordered_map<Tune,int> Tune2Freq;

class buzzer {
private:
    PwmOut IO;
public:
    buzzer(PinName Pin_PWMOUT): IO(Pin_PWMOUT) {
        IO.write(0.f);
    }
    ~buzzer() {}

    buzzer & SetTune(Tune tune_input = Tune::Pause);
    buzzer & PlayMusic(const vector<Tune> &Music, float NotePerMin);
    buzzer & PlayMusic(const vector<pair<Tune,float>> &Music, float NotePerMin);
    // 小星星 完整曲子
    buzzer & DemoMusic_1(void);
    // 春日影 前11个小节
    buzzer & DemoMusic_2(void);
};

}

using DT5EDU::buzzer;

#endif //_CATEDS_MS_Buzzer_